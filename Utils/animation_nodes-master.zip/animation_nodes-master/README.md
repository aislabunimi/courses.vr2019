#Animation Nodes

The Animation Nodes addon (AN) implements a new node system for [Blender](http://blender.org).

You can find some documentation here: http://animation-nodes-manual.readthedocs.org/en/latest/
